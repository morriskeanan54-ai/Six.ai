# Six AI starter prototype

This is the first front-end prototype for Six AI. It is mobile-friendly and can be hosted as a static website.

## Files
- `index.html` — page structure
- `style.css` — responsive dark interface
- `app.js` — basic demo interactions

## Important
This is only a user-interface prototype. It is not connected to a live AI model and does not provide real long-term memory or web search yet. Do not enter private information.

## Publish with GitHub Pages
1. Create a new public repository named `six-ai`.
2. Upload `index.html`, `style.css`, `app.js`, and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then save.
6. Wait for GitHub Pages to publish the site.

Next steps: add a secure backend, connect an AI model through a server-side API key, add authentication and database-backed chat history, then implement opt-in memory and web search. Never put API keys in browser JavaScript.
